// App.js - André Whatsapp (Expo) simple chat app demo
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, SafeAreaView, Image } from 'react-native';
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, serverTimestamp } from 'firebase/firestore';
import FIREBASE_CONFIG from './src/firebaseConfig';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const firebaseApp = initializeApp(FIREBASE_CONFIG);
const db = getFirestore(firebaseApp);

const Stack = createStackNavigator();

function ConversationsScreen({ navigation }) {
  const conv = [{ id: 'andre', title: 'André Whatsapp', subtitle: 'Envie uma mensagem', participantNumber: '+55777' }];
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}><Text style={styles.headerTitle}>Conversa</Text></View>
      <FlatList
        data={conv}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <TouchableOpacity style={styles.convItem} onPress={() => navigation.navigate('Chat', { chatId: item.id, title: item.title })}>
            <Image source={require('./assets/icon.png')} style={styles.avatar}/>
            <View style={{flex:1}}>
              <Text style={styles.convTitle}>{item.title}</Text>
              <Text style={styles.convSubtitle}>{item.subtitle}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}

function ChatScreen({ route }) {
  const { chatId, title } = route.params;
  const [text, setText] = useState('');
  const [messages, setMessages] = useState([]);
  const displayNumber = '+55777';
  const displayName = 'André Fiuza';

  useEffect(() => {
    const q = query(collection(db, 'messages', chatId, 'messages'), orderBy('timestamp'));
    const unsub = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(docs);
    });
    return () => unsub();
  }, [chatId]);

  async function sendMessage() {
    if (!text.trim()) return;
    try {
      await addDoc(collection(db, 'messages', chatId, 'messages'), {
        senderId: 'admin',
        senderName: displayName,
        senderNumber: displayNumber,
        text: text.trim(),
        timestamp: serverTimestamp()
      });
      setText('');
    } catch (err) {
      console.error(err);
      alert('Erro ao enviar mensagem');
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}><Text style={styles.headerTitle}>{title}</Text></View>
      <FlatList
        data={messages}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <View style={styles.messageBubble}>
            <Text style={styles.sender}>{item.senderNumber}{item.senderName ? ` - ${item.senderName}` : ''}</Text>
            <Text style={styles.messageText}>{item.text}</Text>
          </View>
        )}
        contentContainerStyle={{padding:12}}
      />
      <View style={styles.inputRow}>
        <TextInput style={styles.input} placeholder="Digite uma mensagem" value={text} onChangeText={setText} />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage}><Text style={styles.sendButtonText}>Enviar</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Conversations" component={ConversationsScreen} options={{headerShown:false}}/>
        <Stack.Screen name="Chat" component={ChatScreen} options={{headerShown:false}}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, backgroundColor:'#f2f2f2' },
  header: { padding:12, backgroundColor:'#fff', borderBottomWidth:1, borderColor:'#ddd' },
  headerTitle: { fontSize:18, fontWeight:'600', color:'#075E54' },
  convItem: { flexDirection:'row', alignItems:'center', padding:12, backgroundColor:'#fff', margin:8, borderRadius:8 },
  avatar: { width:48, height:48, borderRadius:8, marginRight:12 },
  convTitle: { fontSize:16, fontWeight:'600' },
  convSubtitle: { color:'#666', marginTop:4 },
  messageBubble: { marginBottom:10, backgroundColor:'#fff', padding:10, borderRadius:8 },
  sender: { fontSize:12, color:'#555', marginBottom:4 },
  messageText: { fontSize:15 },
  inputRow: { flexDirection:'row', padding:8, borderTopWidth:1, borderColor:'#eee', backgroundColor:'#fff' },
  input: { flex:1, padding:10, borderRadius:8, borderWidth:1, borderColor:'#ddd', marginRight:8 },
  sendButton: { backgroundColor:'#075E54', paddingHorizontal:14, justifyContent:'center', borderRadius:8 },
  sendButtonText: { color:'#fff', fontWeight:'600' }
});
